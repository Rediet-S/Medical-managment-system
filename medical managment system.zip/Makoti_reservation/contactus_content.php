
<div class="alert alert-info"><strong>Contact US</strong></div>
<div class="about">
    <p>
        349 Kopanong Section
        Thembisa

        011 926 0821

    </p>
</div>
