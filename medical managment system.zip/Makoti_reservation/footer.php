    <footer class="footer">
      <div class="container">
	  <div class="foot-margin">
          <p><a>Copyright 2014. All Rights reserved</a></p>
      </div>
      </div>
    </footer>
	
		<script type="text/javascript">
			$(function() {
				$('#da-thumbs > li').hoverdir();
			});
		</script>
<?php include('tooltip.php'); ?>

</body>
</html>