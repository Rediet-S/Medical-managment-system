<div class="testimonial">	
    <div class="caption_index_2">DOCTOR PROFILE</div>
    <div class="testimonial_div">
        <p>
            Dr Matsatsi Makoti,General practitioner is a  family doctor at 349 kopanong section,Thembisa,Gauteng.
            The services offered are child health,maternal health, men's health, wellness, weight loss, wound care,
            HIV care,General medical care,Elderly and aged care,emergencies,house calls,tourist calls and 
            workman's compensation cases.
            The general practice is equipped for sonar,ECG, lung function, cuattery, flouroscopy X-Ray and minor surgical procedures.
            The doctor does house calls, workplace calls, calls to tourist hotels and guesthouses.
        </p>
    </div>
    <div class="caption_index_2">TESTIMONIAL</div>
    <div class="testimonial_div1">
        <p>
            I was delighted with the treatment. Despite me being a somewhat difficult patient Dr. Matsatsi was really gentle, patient and understanding.
            The treatment was explained precisely to me and the price was quoted right at the beginning which is exactly what the price was at the end.
            The transformation to my life in general has been amazing. 
            I am extremely happy with the quality of the treatment.
        </p>
    </div>
</div>
<div class="contact_us">
    <div class="caption_index_2">Qualifications</div>
    <p>MB CHB-MEDUNSA</p>
    <p>MBA-MEDUNSA</p>
    <div class="caption_index_2">Memberships & Associations</div>
    <p>SAMA - Member</p>
    <div class="caption_index_2">Office Hours</div>
    <p>Monday - Friday (9:00 to 18:00 )</p>
    <p>Saturday(half day)</p>
    <p>349 Kopanong Section</p>
    <p>Thembisa</p>

</div>
