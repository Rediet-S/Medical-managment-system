<?php include('header.php'); ?>
<?php include('session.php'); ?>
    <div class="container">

	<div class="row">	
						<div class="span3">
						<?php include('sidebar.php'); ?>
						</div>
						<div class="span9">
							<img src="../img/dr.jpg" class="img-rounded">
								<?php include('navbar_dasboard.php') ?>
							<div class="body_img">
								<img src="../img/bg.JPG">
							</div>
						</div>
    </div>
<?php include('footer.php') ?>