<div class="container">   
   <footer class="footer">
      <div class="container">
	  <div class="foot-margin">
        <p><a>Copyright 2014. All Rights reserved</a></p>
      </div>
      </div>
    </footer>
</div>
</body>
</html>