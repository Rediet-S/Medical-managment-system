
<div class="alert alert-info"><strong>About US</strong></div>
<div class="about">
   

    <p>
         Dr Matsatsi Makoti,General practitioner is a  family doctor at 349 kopanong section,Thembisa,Gauteng.
            The services offered are child health,maternal health, men's health, wellness, weight loss, wound care,
            HIV care,General medical care,Elderly and aged care,emergencies,house calls,tourist calls and 
            workman's compensation cases.
            The general practice is equipped for sonar,ECG, lung function, cuattery, flouroscopy X-Ray and minor surgical procedures.
            The doctor does house calls, workplace calls, calls to tourist hotels and guesthouses.
       
    </p>

</div>
