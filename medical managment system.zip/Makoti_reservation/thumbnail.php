<ul id="da-thumbs" class="da-thumbs">
    <li>
        <a href="">
            <img src="images/b.jpg" />
            <div><span>Image 1</span></div>
        </a>
    </li>
    <li>
        <a href="">
            <img src="images/c.jpg" />
            <div><span>Image 2</span></div>
        </a>
    </li>
    <li>
        <a href="">
            <img src="images/d.jpg" />
            <div><span>Image 3</span></div>
        </a>
    </li>
    <li>
        <a href="">
            <img src="images/e.jpg" />
            <div><span>Image 4</span></div>
        </a>
    </li>



</ul>
<div class="social_con">
    <div class="social_index">
        <div class="mm"><img src="img/32x32/facebook.png"></div><div class="fb">Like us On facebook</div>						
    </div>
    <div class="social_index">
        <div class="mm"><img src="img/32x32/twitter.png"></div><div class="twitter">Follow us on twitter</div>
    </div>
    <div class="social_index">
        <div class="mm"><img src="img/32x32/rss.png"></div><div class="rss">Feed us On Rss</div>
    </div>
</div>

