<div class="life-side-bar">
    <div class="hero-container">                  
        <ul class="nav nav-tabs nav-stacked">
            <li class="active">
                <a href="#" class="yellow_link"><i class="icon-home icon-large icon-large"></i>&nbsp;Home</a>
            </li>
            <li>
                <a class="yellow_link" href="#"><i class="icon-info icon-large"></i>&nbsp;About US</a>
            </li>
            <li><a  class="yellow_link"  href="#"><i class="icon-phone icon-large"></i>&nbsp;Contact US</a></li>
            <li><a  class="yellow_link" href="#"><i class="icon-sitemap icon-large"></i>&nbsp;Site Map</a></li>
        </ul>
    </div>
</div>